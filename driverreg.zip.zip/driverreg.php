
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Driver Registration</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
  <style>
 body{
background-image:url("images/bg1.png");
background-size:cover;
 
 }
</style>
</head>

<body >
 
<?php include('indexmenu.php'); ?>
<div class="container" style="margin-top:50px; background-color:transparent;">
 <form class="text-center border border-light p-5" style="width:60%; margin-left:auto; margin-right:auto;" >
 <p class="h4 mb-4">DRIVER REGISTRATION</p>
<table class="form-row mb-4 row">
    

    
    <tr>
       
    <td><label>Licence Id</label></td>
	<td><input type="text" id="defaultRegisterForm Booktitle"  class="form-control" name="id" required></td></tr>
	<tr>
       
    <td><label>Name</label></td>
	<td><input type="text" id="defaultRegisterForm Booktitle"  class="form-control" name="name" required></td></tr>
	<tr>
	<td><label>Vehicle Type</label></td>
	
			<td><select class="browser-default custom-select" name="type" required>
  <option selected>Select Type</option>
  <option value="Car">Car</option>
  <option value="Bus">Bus</option>
  <option value="lory">Lory</option>
  <option value="auto">Auto</option>
</select></td></tr>
	<tr><td><label>Vehicle Number</label> </td>
	<td><input type="text" id="defaultRegisterForm Booktitle"  class="form-control" name="number" required></td></tr>
    <tr><td><label>Address</label> </td>
	<td><input type="text" id="defaultRegisterForm Bookauthor" class="form-control" name="address" required></td></tr><br>
	<tr><td><label>Password</label></td>
	<td><input type="password" id="defaultRegisterForm Publication" class="form-control" name="pass" required></td></tr><br>
	 	 <tr><td><label>Confirm Password</label></td>
	<td><input type="password" id="defaultRegisterForm Publication" class="form-control" name="con" required></td></tr><br>
	 	   </table>  
	<button class="btn btn-info my-4 btn-block" type="submit">Submit</button>
	<button class="btn btn-info my-4 btn-block" type="submit">Cancel</button>
  
		</div>
	
	  

	   </form>
	  
		</body>
		</html>